# Verben mit Präpositionen (APK)

1. Buat repositori baru di GitHub, lalu unggah SEMUA isi folder ini (termasuk folder tersembunyi `.github`).
2. Buka tab **Actions** -> workflow **Build APK** (jalan otomatis; atau klik **Run workflow**).
3. Setelah hijau, buka run-nya, unduh artifact **verben-mit-praepositionen-apk** (ZIP berisi `app-debug.apk`).
4. Ekstrak ZIP, kirim APK ke HP, lalu instal (izinkan "instal dari sumber ini").

Jika folder `.github` tidak ikut terunggah: di GitHub pilih Add file -> Create new file, ketik
`.github/workflows/build.yml`, lalu salin isinya dari ZIP ini.
